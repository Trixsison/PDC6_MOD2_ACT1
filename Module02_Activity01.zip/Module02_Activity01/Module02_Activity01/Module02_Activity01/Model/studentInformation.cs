﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Module02_Activity01.Model
{
    class studentInformation
    {
        public int studentID { get; set; }
        public string studentName { get; set; }
        public string yearLevel { get; set; }
        public string section { get; set; }
        public string courseCode { get; set; }
        public string course { get; set; }
    }
}
