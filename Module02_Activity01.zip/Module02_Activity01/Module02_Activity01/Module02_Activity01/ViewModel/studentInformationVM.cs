﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;
using Module02_Activity01.Model;
using Xamarin.Forms;

namespace Module02_Activity01.ViewModel
{
    class studentInformationVM:INotifyPropertyChanged
    {
     public studentInformation StudentInfo { get; set; }

    public Command CommandInformationUpdate { get; set; }

        public int ID { get; set; }
        public string name { get; set; }
        public string yrlvl { get; set; }
        public string section { get; set; }
        public string crscode { get; set; }
        public string crs { get; set; }

        public studentInformationVM()
        {
            CommandInformationUpdate = new Command(() =>
            {
                StudentInfo = new studentInformation
                {
                    studentID = ID,
                    studentName = name,
                    yearLevel = yrlvl,
                    section = section,
                    courseCode = crscode,
                    course = crs
                };
                OnPropertyChanged(nameof(StudentInfo));
            });
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
