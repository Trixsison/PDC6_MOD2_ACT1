﻿using System;
using System.Collections.Generic;
using Module02_Activity01.ViewModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Module02_Activity01.View
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class pageView1 : ContentPage
    {
        public pageView1()
        {
            InitializeComponent();
            BindingContext = new studentInformationVM();
        }
    }
}